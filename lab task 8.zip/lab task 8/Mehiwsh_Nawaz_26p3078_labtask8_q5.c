#include<stdio.h>
void showBalance(const float *balance);
void deposit(float *balance,float amount);
int withdraw(float *balance,float amount);

int main()
{
float balance=5000.00;
float amount;
int choice;
do{
printf("-----BANK ACCOUNT-----\n");
printf("1. Check Balance\n");
printf("2. Deposit\n");
printf("3. Withdraw\n");
printf("4. Exit\n");
printf("Enter Choice:");
scanf("%d",&choice);
if(choice==1){
showBalance(&balance);
}
else if(choice==2){
printf("Enter amount to deposit:");
scanf("%f",&amount);
deposit(&balance,amount);
}
else if(choice==3){
printf("Enter amount to withdraw:");
scanf("%f",&amount);
if(withdraw(&balance,amount)==1){
printf("Withdrew successfully!\n");
}
else {
printf("Insufficient funds or invalid aount");
}
}
else if(choice==4)
{
printf("Goodbye!");
}
else 
{
printf("Invalid choice.\n");
}
}while(choice !=4);


return 0;
}

void showBalance(const float *balance){
printf("Current balance: Rs %.2f\n",*balance);
}

void deposit(float *balance,float amount){
if(amount>0){
*balance=*balance+amount;
printf("Deposited successfully!\n");
}
else{
printf("Invalid deposit amount.\n");
}
}

int withdraw(float *balance,float amount){
if(amount>0 && amount<=*balance)
{
*balance=*balance-amount;
return 1;
}
return 0;
}

