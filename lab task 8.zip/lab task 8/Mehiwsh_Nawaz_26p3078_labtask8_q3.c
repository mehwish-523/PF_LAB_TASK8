#include<stdio.h>
void circleInfo(double radius, double *area, double *circumference);
int main()
{
double radius,area,circumference;
printf("Enter radius:");
scanf("%lf",&radius);
while(radius<0)
{
printf("radius cannot be negative. Enter again:");
scanf("%lf",&radius);
}
circleInfo( radius, &area, &circumference);
printf("Area=%.2f\n",area);
printf("Circumference=%.2f\n",circumference);
   return 0;
}

void circleInfo(double radius, double *area, double *circumference){
*area=3.14159*radius*radius;
*circumference=2*3.14159*radius;
}
