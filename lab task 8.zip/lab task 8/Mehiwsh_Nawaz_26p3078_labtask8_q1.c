#include<stdio.h>
int main()
{
 int age;
float cgpa;
char grade;
printf("Enter age:");
scanf("%d",&age);
printf("Enter cgpa:");
scanf("%f",& cgpa);
printf("Enter grade:");
scanf(" %c",&grade);
int *page=&age;
float *pcgpa=&cgpa;
char *pgrade=&grade;
printf("age = %d\n",age);
printf("&age = %p\n",&age);
printf("page = %p\n",page);
printf("via pointer = %d\n",*page);

printf("cgpa = %.2f\n",cgpa);
printf("&cgpa = %p\n",&cgpa);
printf(" pcgpa= %p\n",pcgpa);
printf("via pointer = %.2f\n",*pcgpa);

printf("grade = %c\n",grade);
printf(" &grade= %p\n",&grade);
printf("pgrade = %p\n",pgrade);
printf("via pointer = %c\n",*pgrade);

printf("&page = %p\n",&page);
printf(" &pcgpa = %p\n",&pcgpa);
printf("&pgrade = %p\n",&pgrade);

*page=*page+1;
*pcgpa=*pcgpa+0.25;
*pgrade=*pgrade+1;
printf("After changing through pointers:\n");
printf("age = %d\n",age);
printf("cgpa = %.2f\n",cgpa);
printf("grade = %c\n",grade);

// age changed because page stores the memory address of age,and modifying *page directly updates thhe value at that memorylocation.
return 0;
}
