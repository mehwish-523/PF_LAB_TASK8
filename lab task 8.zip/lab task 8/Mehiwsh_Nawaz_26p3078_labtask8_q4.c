#include<stdio.h>
void convertTime(int totalSeconds, int *h, int *m, int *s);
void addSeconds(int *h,int *m, int *s, int extra);
int main()
{
int totalSeconds,extra,h,m,s;
printf("Enter total second:");
scanf("%d",&totalSeconds);
convertTime( totalSeconds, &h, &m, &s);
printf("Converted: %dh %dm %ds\n",h,m,s);
printf("Enter extra seconds to add:");
scanf("%d",&extra);
addSeconds(&h,&m,&s,extra);
printf("Updated: %dh %dm %ds\n",h,m,s);

return 0;
}

void convertTime(int totalSeconds, int *h, int *m, int *s){
*h=(totalSeconds/3600);
*m=(totalSeconds%3600)/60;
*s=totalSeconds%60;
}

void addSeconds(int *h,int *m,int *s,int extra){
int total;
total=(*h *3600)+(*m *60)+*s+extra;
convertTime(total,h,m,s);
}
