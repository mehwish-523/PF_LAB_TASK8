#include<stdio.h>
#include<math.h>
int solveQuadratic(double a,double b, double c,double *r1, double *r2);

int main()
{
double a,b,c,r1,r2;
int count;
printf("Enter a,b,c:");
scanf("%lf %lf %lf",&a,&b,&c);
count=solveQuadratic( a, b,  c, &r1,  &r2);
if(count==2)
{
printf("Two roots:%.2f and %.2f\n",r1,r2);
}
else if(count==1)
{
printf("One root: %.2f\n",r1);
}
else if(count==0){
printf("No real roots.\n");
}
return 0;
}
 int solveQuadratic(double a,double b, double c,double *r1, double *r2){

double d=(b*b)-(4*a*c);
if(d>0)
{
*r1=(-b+sqrt(d))/(2*a);
*r2=(-b-sqrt(d))/(2*a);
return 2;
}
else if(d==0){
*r1=-b/(2*a);
return 1;
}
else 
{
return 0;
}
}
// C function can only return one value directly,so we returned the number of roots and used pointers to pass back up to two root values.

